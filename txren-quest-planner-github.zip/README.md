# Texas Renaissance Quest Planner

An interactive React web application created for Project 4, Option 2.

The application receives input from users, displays the saved input as quest cards, and stores the data in the browser using `localStorage`.

## Features

- Create quests, episode ideas, challenges, characters, and locations
- Enter a title, type, status, character, location, and description
- Display saved entries as responsive cards
- Search saved entries
- Filter entries by category
- Mark entries complete or reopen them
- Delete entries
- Automatically save data with `localStorage`
- Responsive CSS Grid layout
- Gradient background
- Original inline SVG image
- Semantic HTML5 elements
- Required `Integral application doman` comments in HTML, CSS, and JavaScript
- Footer with GitHub repository and deployed website links

## Project Option

**Option 2:** Original application created independently by Kaylee York.

## GitHub Repository

https://github.com/kayleeyork-create/txren-quest-planner

## Deployed Website

https://www.txrengame.com

## How to Publish with GitHub Pages

1. Create a repository named `txren-quest-planner`.
2. Upload `index.html`, `README.md`, and `.nojekyll`.
3. Open the repository **Settings**.
4. Select **Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select the `main` branch and `/ (root)` folder.
7. Save the settings.

GitHub Pages will publish the project at:

`https://kayleeyork-create.github.io/txren-quest-planner/`

## Custom Domain

The project links to:

https://www.txrengame.com

To connect that domain to GitHub Pages, configure the domain's DNS records and enter `www.txrengame.com` in the GitHub Pages custom-domain field.

## Author

Kaylee York  
GitHub username: `kayleeyork-create`
